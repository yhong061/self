#include "epcthread.h"
#include <math.h>
typedef unsigned short int uint16_t;
typedef short int int16_t;
typedef unsigned int uint32_t;
typedef int int32_t;

typedef struct _EpcCalcInfo_ {
	char 			*pDatabuf;
	unsigned int 	mDatabufSize;
	unsigned int 	mDatabufOffset;
	char 			*pCalcbuf;
	unsigned int 	mCalcbufSize;
	unsigned int 	mCalcbufOffset;
}EpcCalcInfo;

int EpcCalcInfo_Init(EpcCalcInfo *calcinfo)
{
	unsigned int dcs = 4;
	unsigned int imagesize = WIDTH * HEIGHT * sizeof(unsigned short) * dcs;
	
	calcinfo->mDatabufOffset = DATA_INFO_SIZE;
	calcinfo->mDatabufSize = imagesize + DATA_INFO_SIZE;
	calcinfo->pDatabuf = malloc(calcinfo->mDatabufSize);
	if(calcinfo->pDatabuf == NULL) {
		ERR("mallco calcinfo->pDatabuf fail, return\n");
		return -1;
	}
	FILE *fp = NULL;
	char filename[128];
	filename[0] = '\0';
	sprintf(filename, "%s/in.bin", DATA_PATH);
	fp = fopen(filename, "rb");
	if(fp == NULL) {
		ERR("open %s fail\n", filename);
		free(calcinfo->pDatabuf);
		calcinfo->pDatabuf = NULL;
		return -1;
	}

	char *buf = calcinfo->pDatabuf + calcinfo->mDatabufOffset;
	unsigned int readsize = fread(buf, 1, imagesize, fp);
	if(readsize != imagesize)
		DBG("readsize[%d] != imagesize[%d]\n", readsize, imagesize);
	fclose(fp);

	EpcDataInfo *datainfo = (EpcDataInfo *)calcinfo->pDatabuf;
	datainfo->mBufIdx = 0;
	datainfo->mWidth = WIDTH;
	datainfo->mHeight = HEIGHT;
	datainfo->mDcs = dcs;
	datainfo->mSequence = 0;
	datainfo->mDatasize = readsize;

	imagesize = WIDTH * HEIGHT * sizeof(unsigned short) * 2;
	calcinfo->mCalcbufOffset = DATA_INFO_SIZE;
	calcinfo->mCalcbufSize = imagesize + DATA_INFO_SIZE;
	calcinfo->pCalcbuf = malloc(calcinfo->mCalcbufSize);
	if(calcinfo->pCalcbuf == NULL) {
		free(calcinfo->pDatabuf);
		calcinfo->pDatabuf = NULL;
		ERR("mallco calcinfo->pCalcbuf fail, return\n");
		return -1;
	}

	return 0;
}



typedef struct _EpcPruInfo_ {
	unsigned int 	icType;
	unsigned int 	partType;
	unsigned int 	partVersion;
	uint16_t 		waferID;
	uint16_t 		chipID;

	int rowReduction;
	int colReduction;
	int numberOfHalves;
}EpcPruInfo;

static int calibrationEnable = 1;
static int32_t correctionMap[328 * 252];
static int32_t subCorrectionMap[328 * 252];
static uint16_t nColsMax = 328;
static uint16_t nCols    = 320;
static uint16_t nRowsMax = 252;
static uint16_t nRows    = 240;
static int availableCalibration = 0;

static int offsetPhaseDefault = 0;
static double calibrationTemperature = 0;
static int offsetPhaseDefaultEnabled = 1;
static int offsetPhase = 0;

int calibrationLoadOffset(const int storeID, EpcPruInfo *pruinfo){
	char pathUserOffset[64];
	sprintf(pathUserOffset, "./calibration/PT%02i_W%03i_C%03i_offset_user_%i.bin"
		, pruinfo->partType, pruinfo->waferID, pruinfo->chipID, storeID);
	FILE *fileUserOffset = fopen(pathUserOffset, "rb");
	printf("open %s\n", pathUserOffset);
	if (fileUserOffset == NULL) { //if user offset is not existing, load factory offset
		char pathOffsetFactory[64];
		sprintf(pathOffsetFactory, "./calibration/PT%02i_W%03i_C%03i_offset_factory_%i.bin"
			, pruinfo->partType, pruinfo->waferID, pruinfo->chipID, storeID);
		FILE *fileOffsetFactory = fopen(pathOffsetFactory, "rb");
		printf("open %s\n", pathOffsetFactory);
		if (fileOffsetFactory == NULL) {
			memset(correctionMap, 0, nColsMax * nRowsMax * sizeof(int32_t));
			memset(subCorrectionMap, 0, nColsMax * nRowsMax * sizeof(int32_t));
			availableCalibration = 1;
			return -1;
		}
		fread(&offsetPhaseDefault, sizeof(int), 1, fileOffsetFactory);
		if (!fread(&calibrationTemperature, sizeof(double), 1, fileOffsetFactory)) {
			calibrationTemperature = 45.0;
		}
		if (offsetPhaseDefaultEnabled) {
			offsetPhase = offsetPhaseDefault;
		}
		fclose(fileOffsetFactory);
		return 1;
	}

	fread(&offsetPhaseDefault, sizeof(int), 1, fileUserOffset);
	if (!fread(&calibrationTemperature, sizeof(double), 1, fileUserOffset)) {
		calibrationTemperature = 45.0;
	}
	if (offsetPhaseDefaultEnabled) {
		offsetPhase = offsetPhaseDefault;
	}
	fclose(fileUserOffset);
	return 1;
}

void calibrationSetCorrectionMap(EpcPruInfo *pruinfo) {
	if (calibrationEnable) {	
		int i;
		int rowReduction = pruinfo->rowReduction;
		int colReduction = pruinfo->colReduction;
		int numberOfHalves = pruinfo->numberOfHalves;

		const int topLeftX = 4;
		const int bottomRightX = 323;
		const int topLeftY = 6;
		const int bottomRightY = 125;
		int middlePart;
		int topBottomPart;

		middlePart = ((nRowsMax/2-1 - bottomRightY) / rowReduction) * numberOfHalves * (nColsMax / colReduction);
		topBottomPart = (nColsMax / colReduction) * (nRowsMax / rowReduction) - (topLeftY / rowReduction) * numberOfHalves * (nColsMax / colReduction);

		int sub = 0; // index for subCorrectionMap
		for (i = 0; i < (nColsMax / colReduction) * (nRowsMax / rowReduction); i++) {
			if (i < middlePart || i >= topBottomPart) { // check whether i is on a valid row
				//do nothing
			} else if ((i % (nColsMax / colReduction) < topLeftX) || (i % (nColsMax / colReduction) > bottomRightX)) {  // check whether i is on a valid column
				//do nothing
			} else {
				subCorrectionMap[sub] = correctionMap[i];
				sub++;
			}
		}
	}
}

int calibrationLoadFPN(const int storeID, EpcPruInfo *pruinfo) {
	if (calibrationEnable == 0) { //if FPN disabled
		memset(correctionMap, 0, nColsMax * nRowsMax * sizeof(int32_t));
		memset(subCorrectionMap, 0, nColsMax * nRowsMax * sizeof(int32_t));
		availableCalibration = 0;
		return 0;
	}
	char pathUserFPN[64];
	sprintf(pathUserFPN, "./calibration/PT%02i_W%03i_C%03i_calibration_user_%i.bin"
		, pruinfo->partType, pruinfo->waferID, pruinfo->chipID, storeID);
	FILE *fileUserFPN = fopen(pathUserFPN, "rb");
	printf("open %s\n", pathUserFPN);
	if (fileUserFPN == NULL) { //if user calibration is not existing, load factory calibration
		char pathFPNFactory[64];
		sprintf(pathFPNFactory, "./calibration/PT%02i_W%03i_C%03i_calibration_factory_%i.bin"
			, pruinfo->partType, pruinfo->waferID, pruinfo->chipID, storeID);
		FILE *fileFPNFactory = fopen(pathFPNFactory, "rb");
		printf("open %s\n", pathFPNFactory);
		if (fileFPNFactory == NULL ) {	// if error, try again
			fileFPNFactory = fopen(pathFPNFactory, "rb");
			if (fileFPNFactory == NULL ){
				memset(correctionMap, 0, nColsMax * nRowsMax * sizeof(int32_t));
				memset(subCorrectionMap, 0, nColsMax * nRowsMax * sizeof(int32_t));
				availableCalibration = 1;
				return -1;
			}
		}
		fread(correctionMap, sizeof(int32_t), nColsMax * nRowsMax, fileFPNFactory);
		fclose(fileFPNFactory);
		calibrationSetCorrectionMap(pruinfo);
		availableCalibration = 2;
		return 1;
	}

	fread(correctionMap, sizeof(int32_t), nColsMax * nRowsMax, fileUserFPN);
	fclose(fileUserFPN);
	calibrationSetCorrectionMap(pruinfo);
	availableCalibration = 3;
	return 1;
}


int calibrationGetOffsetPhase() {
	return offsetPhase;
}

int32_t* calibrationGetCorrectionMap() {
	return subCorrectionMap;
}


struct TofResult{
	int16_t dist;
	int16_t amp;
};

#define MAX_DIST_VALUE 	3000
#define LOW_AMPLITUDE 	30000
#define SATURATION 		31000
#define ADC_OVERFLOW 	32000
#define MODULO_SHIFT 	30000
#define FP_M_2_PI 		3217.0 	/*! 2 PI in fp_s22_9 format*/
#define FP_M_PI			1608.5;


static uint16_t pixelMask = 0xFFF; // epc660, epc502
static uint16_t saturationBit = 0x1000; // epc660, epc502
static uint16_t adcMin = 1;    // epc660, epc502
static uint16_t adcMax = 4094; // epc660, epc502

#define fp_fract 9
#define coeff_1 101
#define coeff_2 503
#define coeff_3 402

int32_t *calibrationMap;


/*static*/ inline int32_t __fp_mul(int32_t a, int32_t b)
{
    int32_t r = (int32_t)((int32_t)((int32_t)a * b)>>fp_fract);

    return r;
}

/*static*/ inline int32_t __fp_div(int32_t a, int32_t b)
{
    int32_t r = (int32_t)((((int32_t)a<<fp_fract))/b);

    return r;
}


/*static*/ inline int32_t fp_atan2(int16_t y, int16_t x)
{
    int32_t fp_y = ((int32_t)y<<fp_fract);
    int32_t fp_x = ((int32_t)x<<fp_fract);

    int32_t mask = (fp_y >> 31);
    int32_t fp_abs_y = (mask + fp_y) ^ mask;

    mask = (fp_x >> 31);
    int32_t fp_abs_x = (mask + fp_x) ^ mask;

    int32_t r, angle;

    if((fp_abs_y < 100) && (fp_abs_x < 100))
        return 0;


    if (x>=0) { /* quad 1 or 2 */
        /* r = (x - abs_y) / (x + abs_y)  */
        r = __fp_div((fp_x - fp_abs_y), (fp_x + fp_abs_y));

        /* angle = coeff_1 * r^3 - coeff_2 * r + coeff_3 */
        angle =
            __fp_mul(coeff_1, __fp_mul(r, __fp_mul(r, r))) -
            __fp_mul(coeff_2, r) + coeff_3;
    } else {
        /* r = (x + abs_y) / (abs_y - x); */
        r = __fp_div((fp_x + fp_abs_y), (fp_abs_y - fp_x));
        /*        angle = coeff_1 * r*r*r - coeff_2 * r + 3*coeff_3; */
        angle =
            __fp_mul(coeff_1, __fp_mul(r, __fp_mul(r, r))) -
            __fp_mul(coeff_2, r) + 3 * coeff_3;
    }

    if (y < 0)
        return(-angle);     // negate if in quad 3 or 4
    else
        return(angle);
}

struct Position{
	uint16_t x;
	uint16_t y;
	uint32_t indexMemory;
	uint32_t indexSorted;
	uint32_t indexCalibration;
	bool top;
};

static uint32_t hyindex = 0;
static uint32_t nPxDcs;
static uint16_t h = 240;
static uint16_t w = 320;
static uint32_t x = 0, y = 0;
static uint16_t nHalves = 2;
struct Position iteratorDefaultNext(){
	struct Position pos;
	if (nHalves == 2) {
		if (x < w){
			pos.x = x;
			pos.y = h / 2 - 1 - y;
		}else{
			pos.x = x - w;
			pos.y = h / 2 + y;
		}
	} else {
		pos.x = x;
		pos.y = h - 1 - y;
	}
	

	pos.indexMemory = hyindex;
	pos.indexSorted = pos.y * w + pos.x;

	++x;
	if (x == nHalves * w){
		x = 0;
		++y;
	}
	++hyindex;
	return pos;
}

int EpcCalc_Calc4DcsInit(EpcCalcInfo *calcinfo)
{

}

int EpcCalc_Calc4Dcs(EpcCalcInfo *calcinfo)
{
	unsigned int i;
		
	EpcDataInfo *datainfo = (EpcDataInfo *)calcinfo->pDatabuf;
	char *databuf = (char *)calcinfo->pDatabuf + calcinfo->mDatabufOffset;
	char *calcbuf = (char *)calcinfo->pCalcbuf + calcinfo->mCalcbufOffset;
	unsigned int dcssize = datainfo->mDatasize/datainfo->mDcs;
	dcssize /= sizeof(uint16_t);

	struct TofResult tofResult;
	int32_t arg1, arg2;
	uint16_t saturationData;
	uint16_t dcs0,dcs1,dcs2,dcs3;
	uint16_t *src1,*src2,*src3,*src4;
	uint16_t *dst1,*dst2;
	char amplitudeDivider = 2;
	int minAmplitude = 100;
	int offset = calibrationGetOffsetPhase();
	int32_t *calibrationMap = calibrationGetCorrectionMap();

	src1 = (uint16_t *)databuf;
	src2 = (uint16_t *)databuf + dcssize;
	src3 = (uint16_t *)databuf + dcssize * 2;
	src4 = (uint16_t *)databuf + dcssize * 3;

	dst1 = (uint16_t *)calcbuf;
	dst2 = (uint16_t *)calcbuf + dcssize;
	
	for(i=0; i<dcssize; i++) {
		struct Position p = iteratorDefaultNext();
		if(p.indexSorted == 0xe98/2) {
			printf("dsc[%x %x %x %x]\n", *src1, *src2, *src3, *src4);
		}		
		dcs0  = *src1++ & pixelMask;
		dcs1  = *src2++ & pixelMask;
		dcs2  = *src3++ & pixelMask;
		dcs3  = *src4++ & pixelMask;
		saturationData = dcs0 | dcs1 | dcs2 | dcs3;
		arg1 = dcs3 - dcs1;
		arg2 = dcs2 - dcs0;

		if(saturationData & saturationBit) {
			tofResult.amp = SATURATION;
			tofResult.dist = SATURATION;
		}
		else if((dcs0 < adcMin) || (dcs0 > adcMax) || (dcs1 < adcMin) || (dcs1 > adcMax) || (dcs2 < adcMin)	|| (dcs2 > adcMax) || (dcs3 < adcMin) || (dcs3 > adcMax)) {
			tofResult.amp = ADC_OVERFLOW;
			tofResult.dist = ADC_OVERFLOW;
		}
		else {
			tofResult.amp = sqrt(arg1 * arg1 + arg2 * arg2) / amplitudeDivider;
			if(tofResult.amp >= minAmplitude){
				int32_t distance = fp_atan2(arg1, arg2) + FP_M_PI;
				distance = ((distance * MAX_DIST_VALUE) / (double)FP_M_2_PI) + offset + calibrationMap[i] + 0.5;			
				distance = (distance + MODULO_SHIFT) % MAX_DIST_VALUE;
				tofResult.dist = (int16_t) distance;
			}
			else {
				tofResult.dist = LOW_AMPLITUDE;
				tofResult.amp  = LOW_AMPLITUDE;
			}
		}
			
		dst1[p.indexSorted] = tofResult.dist;
		dst2[p.indexSorted] = tofResult.amp;
	}
}

int test_saveFile(char *buf, unsigned int size)
{
	char filename[64];
	FILE *fp = NULL;

	filename[0] = '\0';
	sprintf(filename, "%s/out.bin", DATA_PATH);
	printf("save: %s\n", filename);
	fp = fopen(filename, "wb");
	if(fp) {
		fwrite(buf, 1, size, fp);
		fclose(fp);
	}
	return 0;
}

int EpcPru_Init(EpcPruInfo *pruinfo)
{
	pruinfo->icType = 3;
	pruinfo->partType = 2;
	pruinfo->partVersion = 6;
	pruinfo->waferID = 172;
	pruinfo->chipID = 110;

	pruinfo->rowReduction = 1;
	pruinfo->colReduction = 1;
	pruinfo->numberOfHalves = 2;

	calibrationLoadOffset(28, pruinfo);
	calibrationLoadFPN(28, pruinfo);

	return 0;
}



int test(void)
{
	EpcCalcInfo calcinfo;
	EpcPruInfo pruinfo;
	EpcPru_Init((EpcPruInfo *)&pruinfo);
	EpcCalcInfo_Init((EpcCalcInfo *)&calcinfo);
		
	EpcCalc_Calc4Dcs((EpcCalcInfo *)&calcinfo);

	char *buf = calcinfo.pCalcbuf + calcinfo.mDatabufOffset;
	unsigned int size = calcinfo.mCalcbufSize - calcinfo.mCalcbufOffset;
	test_saveFile(buf, size);
	return 0;
}
