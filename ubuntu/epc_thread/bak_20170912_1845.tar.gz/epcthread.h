#include <pthread.h>  
#include <stdio.h>  
#include <stdlib.h>  
#include <unistd.h>
#include <signal.h>
#include <string.h>

#define DBG(fmt, ...) printf("[EPC][%d]" fmt, __LINE__, ## __VA_ARGS__)
#define ERR(fmt, ...) printf("[EPC][%d]" fmt, __LINE__, ## __VA_ARGS__)

#define DATA_PATH "."

#define WIDTH	(320)
#define HEIGHT	(240)
#define DATA_INFO_SIZE (256)

typedef unsigned int bool;

typedef struct _EpcDataInfo_ {
	unsigned int 		mBufIdx;
	unsigned int 		mWidth;
	unsigned int 		mHeight;
	unsigned int 		mDcs;
	unsigned int 		mSequence;
	unsigned int 		mDatasize;
	struct timeval		mTv;
}EpcDataInfo;

struct _EpcList_ {
	char				*pBuf;
	struct _EpcList_	*pNext;	
};
typedef struct _EpcList_ EpcList_st;

typedef struct _EpcBuffer_ {
	unsigned int		mBufferSize;
	unsigned int		mBufferOffset;
	int    				mBufferCnt;
	int    				mBufferUsed;
	char				*pData;
	
	pthread_mutex_t 	mMutex;

	EpcList_st 			*pEmpty;
	EpcList_st 			*pFull;
}EpcBuffer_st;

typedef struct _EpcData_Range_ {
	unsigned int 		mMin;
	unsigned int 		mMax;
	unsigned int 		mCur;
}EpcData_Range_st;

typedef struct _EpcData_ {
	unsigned int 		mWidth;
	unsigned int 		mHeight;
	unsigned int 		mPixel;
	unsigned int 		mDcs;
	unsigned int 		mImageSize;
	
	EpcData_Range_st	mFilesRange;
}EpcData_st;

typedef struct _EpcCalcCfg_ {
}EpcCalcCfg_st;

typedef struct _EpcCalcThr_ {
	unsigned int		mThreadIdx;
	pthread_t 			mThread;
	unsigned int		mCreated;
	unsigned int		mRunning;
}EpcCalcThr_st;

#define CALC_THR_NUM	(3)
typedef struct _EpcCalc_ {
	unsigned int 		mThrNum;
	pthread_mutex_t 	mMutex;
	unsigned int 		mWidth;
	unsigned int 		mHeight;
	unsigned int 		mPixel;
	unsigned int 		mDistSize;
	unsigned int 		mAmpSize;
	
	EpcCalcThr_st		*pThread[CALC_THR_NUM];
	EpcCalcCfg_st		*pCalcCfg[CALC_THR_NUM];
}EpcCalc_st;

typedef struct _EpcConfig_ {
	EpcData_st			*pData;
	EpcBuffer_st		*pDataBuffer;
	EpcCalc_st			*pCalc;
	EpcBuffer_st		*pCalcBuffer;
}EpcConfig_st;

EpcConfig_st gEpccfg;

